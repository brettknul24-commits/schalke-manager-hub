SCHALKE 04 MANAGER HUB — VERSIE 1

Dit is een mobiele webapp (PWA). Upload de volledige map naar een HTTPS webhost (bijv. GitHub Pages, Netlify) en open de URL op je Android-telefoon in Chrome. Kies in Chrome 'Toevoegen aan startscherm' / 'App installeren'.

Belangrijk:
- Een ZIP downloaden of index.html direct openen is niet voldoende om een PWA te installeren. Een HTTPS-webhost is vereist.
- Alle bewerkingen worden lokaal in de browser opgeslagen (localStorage). Exporteer regelmatig een JSON-back-up via Meer.
- Het dashboard berekent cijfers uit het wedstrijdregister. Losse wedstrijdmomenten veranderen doelpunten/assists NIET automatisch, om dubbeltellingen te vermijden. Werk de eindstand en spelerstatistieken bij via hun registers.
- De app synchroniseert niet automatisch met ChatGPT of EAFC27.
- Dit is een niet-officiële fanapp.
